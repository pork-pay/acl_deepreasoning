# Case: mod7_dermatology (模态7)

- 部位: 肌骨  疾病: 创伤  难度: L3
- 源数据 idx: 1933  GPT审查: 通过(无皮肤暴露/无不适内容)

## Question

Question: A 23-year-old man undergoes the procedure shown after sustaining a sports-related hand injury. Prior to reduction and fixation, this specific fracture pattern typically demonstrates a predictable angular deformity. Which of the following best describes the expected direction of the fracture apex and the predominant deforming force acting on the distal fracture fragment?
Options:
A. Apex dorsal; flexion by the flexor digitorum profundus
B. Apex dorsal; extension by the central slip
C. Apex volar; flexion by the flexor digitorum superficialis
D. Apex volar; extension by the terminal extensor tendon
E. Apex volar; extension by the central slip
Please reason step by step, and put your final answer within \boxed{}.

## Answer

<think>
The X-ray shows a hand with intramedullary K-wire fixation of what appears to be the 5th metacarpal (little finger)—this looks like a boxer's fracture (5th metacarpal neck fracture) treated with intramedullary K-wire fixation (e.g., Foucher's bouquet osteosynthesis or antegrade/retrograde intramedullary wiring).

Wait, but the question says "this specific fracture pattern typically shows a predictable angular deformity." Let me look at the X-ray carefully. The K-wires appear to be in the 5th metacarpal... actually, looking at the image, the wires seem to run along the shaft of the 5th metacarpal toward the metacarpal head/neck region. This is typical for a boxer's fracture (5th metacarpal neck fracture).

In a metacarpal neck fracture (boxer's fracture), the typical deformity is apex dorsal angulation, with the distal fragment flexed volarly due to the pull of... Let me think carefully.

Classic teaching: In a boxer's fracture (5th metacarpal neck fracture), the distal fragment is displaced volarly (flexed), producing dorsal angulation (apex dorsal). The deforming force is the interosseous muscles? Actually, the classic teaching is that the distal fragment is flexed by the pull of the intrinsic muscles (interossei), and the proximal fragment is extended by the extensor carpi ulnaris? Hmm.

Let me recall: Metacarpal neck fracture: the distal fragment is displaced volarly (flexed), producing dorsal angulation (apex dorsal). Deforming forces: the interosseous muscles (which insert partly on the proximal phalanx and act as flexors of the MCP joint) pull the distal fragment into flexion. Also, the extensor digitorum communis extends the proximal fragment? Hmm.

But the options list specific tendons: flexor digitorum profundus, central slip, flexor digitorum superficialis, terminal extensor tendon, central slip.

Hmm, wait. Maybe the fracture shown is not a metacarpal neck fracture but a proximal phalanx fracture? Let me look at the image again: the wires run within the metacarpal? In the image, the K-wires appear to be within the 5th metacarpal... actually, looking at the description: the wires run from the metacarpal head region proximally along the shaft, with the bent ends at the distal... hmm.

Let me think about the image: PA and oblique views of the hand showing two intramedullary K-wires in the 5th metacarpal (little finger). The bent ends of the wires are at the distal metaphysis? Actually, the bent ends appear to be near the metacarpal neck/distal shaft. This is consistent with intramedullary fixation of a 5th metacarpal neck fracture (boxer's fracture).

But the options mention central slip and terminal extensor tendon, which relate to phalangeal fractures. For proximal phalanx fractures: the typical deformity depends on the location relative to the insertion of the interossei and extensor mechanism. For proximal phalanx shaft fractures, the proximal fragment is flexed by the interossei, and the distal fragment is extended by the central slip, producing apex volar (apex palmar) angulation. Yes! Classic teaching: proximal phalanx fractures distal to the insertion of the interossei? Hmm.

Let me recall the classic deformities:

- Proximal phalanx fracture: the interosseous muscles flex the proximal fragment at the MCP joint, and the central slip extends the distal fragment at the PIP joint, producing apex volar angulation.

- Middle phalanx fracture: if the fracture is proximal to the FDS insertion, the distal fragment is flexed by the FDS, producing apex volar? Wait: middle phalanx fracture proximal to the FDS insertion: the FDS flexes the distal fragment, producing apex dorsal angulation? Let me think: the FDS inserts on the volar side of the middle phalanx. If the fracture is proximal to the insertion, the distal fragment is flexed volarly by the FDS, producing apex dorsal angulation. If the fracture is distal to the FDS insertion, the proximal fragment is flexed by the FDS, producing apex volar angulation.

Hmm, but the question: "Before reduction and fixation, this specific fracture pattern typically shows a predictable angular deformity. Which of the following best describes the expected direction of the fracture apex and the predominant deforming force acting on the distal fracture fragment?"

Options:

A. Apex dorsal; flexion by FDP
B. Apex dorsal; extension by central slip
C. Apex volar; flexion by FDS
D. Apex volar; extension by terminal extensor tendon
E. Apex volar; extension by central slip

If the fracture is a proximal phalanx fracture, the classic answer: apex volar angulation, with the distal fragment extended by the central slip (and the proximal fragment flexed by the interossei). That's option E.

But wait, the image shows fixation of the metacarpal? Let me examine the image more carefully. The wires appear to be in the 5th ray. In panel a, the wires run from the distal part (near the metacarpal head) proximally? Actually, the bent ends of the wires are at the distal end near the metacarpal neck? Hmm, the wires appear to be within the 5th metacarpal shaft, with the bent tips at the distal metaphysis. This is typical for retrograde intramedullary pinning of a metacarpal neck fracture? Actually, in Foucher's technique, the wires are inserted antegrade from the base? Hmm.

Let me think about the orientation of the hand: the thumb is on the left side of panel b. The fingers point upward. The carpal bones are at the bottom. So the metacarpals are in the middle. The wires are in the most ulnar ray (little finger side). The wires extend from the distal shaft/metacarpal neck region up into... Wait, do the wires appear to extend beyond the metacarpal head into the proximal phalanx? Let me see: in panel a, the wires run obliquely within the region between the metacarpal head and the shaft. The bent ends are at the bottom (proximal?) Hmm.

Actually, let me define the anatomy: in panel a, at the top you see the phalanges (proximal and middle phalanges of the fingers). The metacarpal heads are at the level of the MCP joints. The wires appear to be within the 5th metacarpal? The wires run from the metacarpal head region distally? Hmm, hard to tell.

Looking at the image: on the right side of panel a (ulnar side), there is a long bone with a wire inside; the wire extends from near the top (distal) to the bottom, with a bent end at the bottom. The bone containing the wire appears to be the 5th metacarpal? But wait, the 5th metacarpal should be more toward the ulnar side; the wire seems to be in the ray that aligns with the little finger.

Actually, in panel a, counting the rays: the thumb is not fully visible in panel a (partially on the left). The wires are in the most radial? No...

Let me think about the source of the image: this might be from a paper on intramedullary nailing of metacarpal fractures. The image shows antegrade intramedullary K-wire fixation of a 5th metacarpal neck fracture? The bent ends of the wires are at the distal cortex near the neck.

Alternatively, the image might show fixation of a proximal phalanx fracture with intramedullary wires.

Let me consider the options: the question asks about the apex direction and the deforming force on the distal fragment. For a metacarpal neck fracture (boxer's), the distal fragment is flexed volarly due to the pull of the interossei (intrinsic muscles), producing apex dorsal angulation. But the options for apex dorsal list FDP flexion (A) or central slip extension (B). Neither mentions interossei. So if it's a metacarpal fracture, the answer would be... hmm, none fits well. Some textbooks say the deforming force in a boxer's fracture is the interossei causing flexion of the distal fragment. But option A says flexion by FDP—FDP does not insert on the metacarpal; it inserts on the distal phalanx, so it's not the deforming force for the metacarpal. Option B: apex dorsal; extension by central slip—the central slip inserts on the base of the middle phalanx, not the metacarpal.

Therefore, the fracture in the image is probably a proximal phalanx fracture? Let me re-express: in a proximal phalanx fracture, the proximal fragment is flexed by the interossei (which insert on the proximal phalanx base/expansion), and the distal fragment is extended by the central slip (which inserts on the middle phalanx base but acts via the extensor mechanism across the PIP). The resulting angulation is apex volar (dorsal displacement? hmm). Wait, apex volar means the apex of the angulation points volarly, i.e., the fracture is angled with volar convexity. If the proximal fragment is flexed (volar) and the distal fragment is extended (dorsal), then the apex is... Let me think geometrically: the proximal fragment is flexed volarly at the MCP; the distal fragment is extended dorsally at the PIP. The fracture line between them forms an angle with the apex pointing volarly? Hmm.

Classic teaching: proximal phalanx fractures typically angulate with apex volar (dorsal angulation? no). Let me recall exactly: "Fractures of the proximal phalanx: the proximal fragment is flexed by the interossei, and the distal fragment is extended by the central slip, producing apex volar angulation." I think that's correct. Yes, I recall that proximal phalanx shaft fractures show apex volar angulation due to the pull of the interossei on the proximal fragment (flexion) and the central slip on the distal fragment (extension). Meanwhile, middle phalanx fractures proximal to the FDS insertion show apex dorsal angulation (distal fragment flexed by FDS), and those distal to the insertion show apex volar.

Hmm wait, let me double-check middle phalanx: FDS inserts on the volar side of the middle phalanx. Fracture proximal to insertion: the distal fragment (which carries the FDS insertion) is flexed volarly → apex dorsal angulation. Fracture distal to insertion: the proximal fragment is flexed by FDS → apex volar angulation. Something like that.

Now the question: "the predominant deforming force acting on the distal fracture fragment." For a proximal phalanx fracture, the distal fragment is extended by the central slip. Apex volar. That's option E.

Option D: apex volar; extension by terminal extensor tendon—the terminal extensor acts on the DIP joint (distal phalanx), not relevant.

Option C: apex volar; flexion by FDS—FDS flexes, which would produce apex dorsal on the distal fragment in a middle phalanx fracture proximal to the insertion.

So the answer is probably E.

But wait, the image: does it show intramedullary wiring of the proximal phalanx of the little finger? Let me look again: in panel a, the wire seems to be in the ray of the index finger? Let me carefully map the bones.

Panel a: at the top, three fingers with proximal and middle phalanges are visible. On the right side, there is a ray with a wire. The wire runs through a long bone that articulates with the proximal phalanx above and the carpus below? The bone with the wire: its distal end (head) articulates with the proximal phalanx of the little finger. The bent end of the wire is at the distal part? Actually, the bent hook of the wire is at the lower end of the wire, which would be proximal? Hmm.

Let me think about typical figures: this image is likely from a paper on "intramedullary fixation of metacarpal fractures," showing antegrade or retrograde wiring. But the question states "after a sports-related hand injury," and the procedure shown is probably intramedullary K-wire fixation of a 5th metacarpal neck fracture (boxer's fracture). Then the expected deformity: apex dorsal angulation with volar displacement of the head; deforming force: interossei? But not in the options.

Hold on. Maybe the question intends a metacarpal neck fracture, and the deforming force on the distal fragment is... Some sources say the distal fragment is flexed by the interossei and the pull of the extensor mechanism? Others say the metacarpal head is flexed volarly due to the pull of the intrinsic muscles. The options don't include interossei. Option A: apex dorsal; flexion by FDP. Some (simplistic) sources might incorrectly attribute it to FDP? Hmm.

Let me think about which is more likely intended. The question seems to be constructed with a specific answer in mind. The options include central slip extension with apex volar (E) and apex dorsal (B). The classic pair: proximal phalanx fracture → apex volar, distal fragment extended by central slip. That's a well-known teaching point. So the answer is E.

But does the image show a proximal phalanx fracture? Let me examine the image again mentally: the wire seems to span from the metacarpal head? Actually, maybe the wire is within the proximal phalanx of the little finger? In panel a, the ray with the wire: at the top you see the middle and distal phalanges? The bone with the wire might be the proximal phalanx, with the metacarpal below it. Let me count the joints: at the bottom of the image is the carpus; above that, the metacarpals; the metacarpal of the wired ray appears to be the 5th metacarpal on the right side of panel a? Hmm, but the wire seems to be in a bone more distal than the metacarpal? The bent end of the wire is at the level of the metacarpal head? I'm not sure.

Let me search my memory: this image might be from the article "Intramedullary nailing of metacarpal fractures" or from a review in the Indian Journal of Orthopaedics on "management of metacarpal fractures." The figure label "a" and "b" with PA and oblique views showing two intramedullary K-wires in the 5th metacarpal. I recall a figure showing "antegrade intramedullary K-wire fixation of a 5th metacarpal neck fracture" with the wires bent at the base? Hmm, but the bent ends appear distal.

Actually, looking at the image: the wires run down the shaft, and the hooked ends are at the distal metaphysis near the neck, which is typical for retrograde? In retrograde intramedullary pinning of a metacarpal neck fracture, the wires are inserted at the base and advanced distally, with the ends bent and cut at the base proximally. In antegrade (from distal), the ends are bent at the distal end.

Alternatively, the wires might be within the proximal phalanx for a proximal phalanx fracture, inserted retrograde from the distal end? Hmm.

Given the options, the question is likely testing knowledge of the deforming forces in phalangeal vs metacarpal fractures. Let me consider each option against known patterns:

- Metacarpal neck/shaft fracture: apex dorsal angulation; distal fragment flexed volarly by interossei (intrinsic muscles). Not in the options (FDP is wrong).

- Proximal phalanx fracture: apex volar; proximal fragment flexed by interossei; distal fragment extended by central slip. Option E matches.

- Middle phalanx fracture proximal to FDS insertion: apex dorsal; distal fragment flexed by FDS. Not exactly in the options (option A says FDP; option C says apex volar with FDS flexion).

- Middle phalanx fracture distal to FDS insertion: apex volar; proximal fragment flexed by FDS. Option C says apex volar; flexion by FDS but acting on the distal fragment—wrong fragment.

The question explicitly asks about the deforming force acting on the distal fracture fragment. For a proximal phalanx fracture, the distal fragment is extended by the central slip → apex volar. So E.

Now, is the fracture in the image a proximal phalanx fracture? The wires in the image: they seem to be in the 5th ray; looking at panel b (oblique), the thumb is visible on the left. The wired bone: its proximal end articulates with the carpus? In panel b, the wired bone appears to be the 5th metacarpal? The bent end is at the distal end near the head.

Hmm, but maybe the image is from a case of "intramedullary fixation of a fractured proximal phalanx"? Let me think about the relative lengths: the metacarpal is longer than the proximal phalanx. The wired bone in panel a looks fairly long, comparable to the metacarpal. The hooked end is at its distal end? Actually, the hook appears to be at the lower part of the wired bone, i.e., proximal? If the hook is proximal, then the wires were inserted antegrade from the base? For metacarpal intramedullary nailing, the wires are often inserted from the distal end (retrograde relative to the hand?) and the ends are bent and left at the base or distal end.

Let me consider the possibility that this figure is from a known article: "Foucher's bouquet osteosynthesis" for 5th metacarpal neck fracture: the wires are inserted at the distal end near the neck and advanced proximally, with the ends bent and cut distally? Actually, in Foucher's technique, the pre-bent wires are inserted antegrade from the proximal end? Hmm.

I think the exact source is: this image appears in a review on hand fractures, perhaps "K-wire fixation of metacarpal fractures." The question may have been written by an exam writer who used the image as a prompt but expects knowledge about boxer's fracture deformity. However, the options don't include interossei. Unless the writer thinks the deforming force on the distal fragment in a boxer's fracture is... Let me recall some literature: "The typical deformity of a metacarpal neck fracture is apex dorsal angulation, with the metacarpal head flexed volarly. This is due to the pull of the interossei and the extensor carpi ulnaris?" Hmm.

Wait, maybe the fracture shown is a metacarpal shaft fracture. Metacarpal shaft fracture: apex dorsal angulation due to the pull of the interossei? Actually, for metacarpal shaft fractures, the deforming forces produce apex dorsal angulation: the proximal fragment is flexed by? Hmm.

Let me recall: metacarpal shaft fracture: the interossei and the pull of the extensor tendons cause apex dorsal angulation. The distal fragment is flexed volarly.

Again, the options don't include interossei.

Given the options, the only internally consistent classic teaching pair is E (apex volar; extension by central slip) for a proximal phalanx fracture. Option B (apex dorsal; extension by central slip) is inconsistent because central slip extension of the distal fragment would produce apex volar when combined with proximal fragment flexion.

But wait: maybe the image shows a proximal phalanx fracture of the little finger fixed with intramedullary wires. Let me look at the image again: in panel a, the wired ray: at the top you see the middle phalanx and distal phalanx? The wired bone is long; above it is a joint (PIP?), then the middle phalanx, then the DIP, then the distal phalanx. Below the wired bone is the MCP joint, then the metacarpal. In panel a, below the wired bone there is indeed another long bone going down to the carpus. Yes! Looking at the image: on the right side, there is a ray with a wire in the upper long bone, and below it another long bone (metacarpal) connecting to the carpus. The wired bone would then be the proximal phalanx of the little finger. Hmm, but the proximal phalanx is shorter than the metacarpal; in the image, the wired bone looks about the same length as the metacarpal below? Hard to judge.

Actually, in panel a, the wired structure: the wire extends from the top (distal phalanx region?) down to the hook. Let me consider the joints visible on that ray: at the top right, there is a phalanx with a tuft; below that a joint; then the wired bone; below that a joint; then the metacarpal; then the carpus. The wired bone is likely the proximal phalanx.

But wait, in panel a, the other fingers show three segments at the top (proximal, middle, distal phalanges). On the wired ray, at the top you see the middle and distal phalanges, and the wired bone is the proximal phalanx. The hook of the wire is at the base of the proximal phalanx? The hook appears at the lower end of the wired bone, which would be the base of the proximal phalanx. That's consistent with antegrade intramedullary pinning of a proximal phalanx fracture? Usually, intramedullary wiring of the proximal phalanx is done retrograde from the distal end? Hmm, but the bent ends are often left at the base? Not sure.

Alternatively, the wired bone might be the 5th metacarpal, with the hook at the distal neck. In panel a, the 5th metacarpal should be the most ulnar long bone connecting to the carpus. The wired bone does appear to connect to the carpus at the bottom? Looking at the image, on the right side of panel a, at the bottom, the 5th metacarpal base articulates with the hamate. The wired bone: its lower end appears to be at the level of the metacarpal head of the other rays? The other metacarpal heads are at the mid-image level. The hook of the wire is slightly below the level of the other metacarpal heads? Hmm.

Let me think about the relative positions: in panel a, the metacarpal heads of the index, middle, and ring fingers are at approximately the same horizontal level. The hooked end of the wire appears to be at a level slightly distal to those heads? Actually, the hook appears to be at the same level as the metacarpal heads/neck region. So the wired bone might be the 5th metacarpal, with the hook at its distal end (neck), and the wire running proximally up the shaft? But the wire in the image runs obliquely with the hook at the bottom (proximal?). Ugh.

Let me look at the image description again: in panel a, the wire appears as two parallel lines running obliquely from upper right to lower left within the bone, with the hook (bent end) at the lower end. The upper end of the wire reaches the distal part of the bone (head/phalanx?). The bone containing the wire: its upper end articulates with a phalanx that looks like the proximal phalanx? At the top right of panel a, you see a bone that looks like the proximal phalanx with a fracture? Hmm.

Given the ambiguity, the question likely comes from a question bank where the image shows intramedullary fixation of a proximal phalanx fracture? Or a metacarpal fracture? Let me think about the phrase "sports-related hand injury"—boxer's fracture is usually from a punch, not sports per se. Proximal phalanx fractures occur in sports (e.g., ball injuries).

The question: "Before reduction and fixation, this specific fracture pattern typically shows a predictable angular deformity." For a proximal phalanx fracture, the predictable deformity is apex volar due to interossei flexing the proximal fragment and central slip extending the distal fragment. The question asks for "the expected direction of the fracture apex and the predominant deforming force acting on the distal fracture fragment" → apex volar; extension by central slip → E.

I think the intended answer is E.

Let me double-check with known question banks: I recall a similar question: "A 23-year-old man sustains a fracture of the proximal phalanx... Which of the following describes the deformity?" Answer: "Apex volar angulation due to flexion of the proximal fragment by the interossei and extension of the distal fragment by the central slip." Yes.

The image with intramedullary wires in the proximal phalanx of the little finger supports this.

Actually, let me confirm the anatomy in the image once more: in panel b (oblique view), the thumb is clearly visible on the left with its two phalanges and metacarpal. On the right side, the wired bone: below it, you can see the metacarpals of the other fingers converging to the carpus. The wired bone appears to be at the level of the metacarpals? In panel b, the metacarpals of the index through little fingers are seen as four long bones; the wired bone is the most ulnar one and appears to be the 5th metacarpal? The hook is at its distal end? Hmm.

But in panel b, the wired bone looks like it's on top of the 5th metacarpal? I can see the 5th metacarpal shaft below the hook? The hook is at the level of the metacarpal head, and the wire runs proximally? No wait, the wire runs distally from the hook? The hook is at the lower end of the wire; the wire extends upward (distally) through the bone that articulates with the middle phalanx? I'm going in circles.

Let me consider the source of the image: searching my memory: this figure might be from the article "Intramedullary nailing of metacarpal fractures" or from a review in the Indian Journal of Orthopaedics on "management of metacarpal fractures." The figure label "a" and "b" with PA and oblique views showing two intramedullary K-wires in the 5th metacarpal. I recall a figure showing "antegrade intramedullary K-wire fixation of a 5th metacarpal neck fracture" with the wires bent at the base? Hmm, but the bent ends appear distal.

Given the options, if the fracture is a metacarpal neck, the expected answer per some question writers might be "apex dorsal; flexion by the interossei," but that's not offered. So they must intend a proximal phalanx fracture. Unless they think the deforming force in a boxer's fracture is FDP? That would be wrong.

Actually, wait. Let me reconsider: maybe the image shows a fracture of the proximal phalanx of the little finger fixed with intramedullary K-wires. The wires are inserted antegrade from the base? The hook at the base is typical for proximal phalanx intramedullary fixation? Usually, for proximal phalanx fractures, intramedullary screws or wires are inserted antegrade from the base? There's a technique using antegrade intramedullary K-wires inserted at the base of the proximal phalanx. The bent ends are left at the base. In the image, the hook is at the lower end of the wired bone; if the wired bone is the proximal phalanx, its base is at the bottom (near the metacarpal head). Yes! The hook is at the bottom near the MCP joint level. The wire runs distally up the shaft of the proximal phalanx toward the head. That fits: the wired bone is the proximal phalanx, and the hook is at its base.

Looking at panel a: the hooked end is at the level just distal to the metacarpal heads of the other fingers, consistent with the base of the proximal phalanx. Good.

Therefore, the fracture is a proximal phalanx fracture (little finger). Deformity: apex volar (volar apex? let me double-check the direction terminology). Standard teaching: proximal phalanx fractures angulate with apex volar (i.e., apex pointing palmar) because the proximal fragment is flexed by the interossei and the distal fragment is extended by the central slip. Yes.

Thus, the answer: E.

Let me also double-check option D: terminal extensor tendon extends the distal phalanx at the DIP; not relevant to the distal fragment of a proximal phalanx fracture.

Therefore, the final answer: E.

Now, let me write the step-by-step reasoning: identify the image as intramedullary K-wire fixation of a proximal phalanx fracture (little finger). Deforming forces: interossei flex the proximal fragment at the MCP; central slip extends the distal fragment at the PIP; the result is apex volar angulation. The distal fragment is pulled into extension by the central slip. Answer E.

I should present the reasoning concisely and give the final answer \boxed{E}.
</think>

Looking at the radiographs, there are intramedullary K‑wires within the proximal phalanx of the little finger – this is intramedullary fixation of a **proximal phalanx fracture**.

**Deforming forces in proximal phalanx fractures:**
- The **proximal fragment** is pulled into flexion by the intrinsic muscles (interossei), which insert near its base and act as MCP flexors.
- The **distal fragment** is pulled into **extension** by the **central slip** of the extensor mechanism, which inserts on the base of the middle phalanx and extends the PIP joint.

**Resulting deformity:** With the proximal segment flexed volarly and the distal segment extended dorsally, the fracture angulates with its **apex pointing volar (apex volar/palmar angulation)**. This is the classic, predictable deformity of proximal phalanx shaft fractures.

**Checking the other options:**
- A (apex dorsal, FDP): FDP acts on the distal phalanx; it does not deform a proximal phalanx fracture, and apex dorsal is the pattern of middle phalanx fractures proximal to the FDS insertion.
- B (apex dorsal, central slip): Central slip extension of the distal fragment produces apex *volar*, not dorsal, angulation – internally inconsistent.
- C (apex volar, FDS flexion): FDS flexion of a distal fragment would produce apex *dorsal* angulation (middle phalanx fracture proximal to insertion).
- D (terminal extensor): The terminal tendon acts only on the DIP joint/distal phalanx, not on a proximal phalanx fragment.

Therefore, the expected deformity is apex volar angulation with the distal fragment extended by the central slip.

\boxed{E}
