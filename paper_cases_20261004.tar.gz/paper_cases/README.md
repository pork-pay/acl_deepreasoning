# 论文 Case 抽样(每模态2题; 图片经 GPT-4.1 视觉审查: 不暴露皮肤外表/不引起生理不适)

来源: cot_over7k_total_token.jsonl(8388行长CoT, 4D标签见 4d_work/)

| 模态 | case | 部位 | 疾病 | 难度 | 图片数 |
|---|---|---|---|---|---|
| mod1_radiography | [mod1_radiography/case1_idx00139](mod1_radiography/case1_idx00139/case.md) | 胸部 | 感染炎症 | L2 | 1 |
| mod1_radiography | [mod1_radiography/case2_idx00019](mod1_radiography/case2_idx00019/case.md) | 胸部 | 血管病变 | L2 | 1 |
| mod2_nuclear_medicine | [mod2_nuclear_medicine/case1_idx02082](mod2_nuclear_medicine/case1_idx02082/case.md) | 胸部 | 肿瘤 | L4 | 1 |
| mod2_nuclear_medicine | [mod2_nuclear_medicine/case2_idx02407](mod2_nuclear_medicine/case2_idx02407/case.md) | 肌骨 | 感染炎症 | L3 | 1 |
| mod3_ultrasound | [mod3_ultrasound/case1_idx04432](mod3_ultrasound/case1_idx04432/case.md) | 胸部 | 肿瘤 | L2 | 1 |
| mod3_ultrasound | [mod3_ultrasound/case2_idx04450](mod3_ultrasound/case2_idx04450/case.md) | 胸部 | 医源性 | L2 | 2 |
| mod4_endoscopy | [mod4_endoscopy/case1_idx05285](mod4_endoscopy/case1_idx05285/case.md) | 胸部 | 创伤 | L2 | 1 |
| mod4_endoscopy | [mod4_endoscopy/case2_idx04524](mod4_endoscopy/case2_idx04524/case.md) | 腹部 | 先天异常 | L3 | 2 |
| mod5_pathology | [mod5_pathology/case1_idx05513](mod5_pathology/case1_idx05513/case.md) | 皮肤软组织 | 代谢内分泌 | L3 | 1 |
| mod5_pathology | [mod5_pathology/case2_idx04931](mod5_pathology/case2_idx04931/case.md) | 胸部 | 代谢内分泌 | L3 | 1 |
| mod6_ophthalmology | [mod6_ophthalmology/case1_idx04495](mod6_ophthalmology/case1_idx04495/case.md) | 头颈部 | 创伤 | L3 | 2 |
| mod6_ophthalmology | [mod6_ophthalmology/case2_idx05010](mod6_ophthalmology/case2_idx05010/case.md) | 头颈部 | 血管病变 | L3 | 1 |
| mod7_dermatology | [mod7_dermatology/case1_idx01607](mod7_dermatology/case1_idx01607/case.md) | 皮肤软组织 | 肿瘤 | L3 | 1 |
| mod7_dermatology | [mod7_dermatology/case2_idx01933](mod7_dermatology/case2_idx01933/case.md) | 肌骨 | 创伤 | L3 | 1 |
| mod8_dental | [mod8_dental/case1_idx05596](mod8_dental/case1_idx05596/case.md) | 头颈部 | 先天异常 | L2 | 1 |
| mod8_dental | [mod8_dental/case2_idx04861](mod8_dental/case2_idx04861/case.md) | 头颈部 | 肿瘤 | L2 | 1 |
| mod9_functional | [mod9_functional/case1_idx04515](mod9_functional/case1_idx04515/case.md) | 神经系统 | 肿瘤 | L2 | 2 |
| mod9_functional | [mod9_functional/case2_idx02910](mod9_functional/case2_idx02910/case.md) | 胸部 | 代谢内分泌 | L3 | 1 |
